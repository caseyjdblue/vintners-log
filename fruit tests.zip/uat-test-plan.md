# Fruited Plains Winery — UAT & End-to-End Test Plan

Reusable acceptance + regression test cases for the single-file app
(`fruited-plains-winery.html`). IDs here match the assertions in
`uat-harness.js`.

## How to run

```
node uat-harness.js [path-to-fruited-plains-winery.html]
```

Defaults to `./fruited-plains-winery.html`. Exit code `0` = all pass, `1` =
one or more failures. The harness runs two layers:

- **Structural (S1–S7):** parses the HTML — router wiring, DOM sections,
  event handlers, IDs, syntax.
- **Behavioral (A–J):** evaluates the app script against a DOM/localStorage
  stub and drives realistic user journeys.

## Environment notes & conventions

- The behavioral layer stubs the DOM (no CSS/layout), so these are
  **logic/acceptance** tests, not visual tests. Visual/responsive checks are
  done manually in a browser.
- **Render targets:** most screens render into their own `#<screen>` section.
  The one exception is Fruit Profiles, whose `renderFruitList()` fills the
  child `#fruit-grid` inside the `#fruit-list` section — assert against
  `#fruit-grid` for that screen.
- The **featured dashboard batch** is the most-recently-`updated_at` active
  batch (not necessarily the first created).
- Temperatures are stored canonically in **°F**; a Celsius preference converts
  on entry/display only.

## Latest run

**2026-06-07 — 45 / 45 PASS** (0 fail).

---

## Structural checks

| ID | Check | Expected |
|----|-------|----------|
| S1 | Every routed screen has a DOM `<section>` | `screens[]` ⊆ DOM section IDs (0 missing) |
| S2 | Event handlers reference defined functions | No `on*` handler calls an undefined function |
| S3 | `go()` targets are registered screens | Every `go('x')` target ∈ `screens[]` |
| S4 | No duplicate element IDs in static DOM | 0 duplicates |
| S5 | No "coming soon" dead-ends for built features | No `go('soon',…)` for shipped features |
| S6 | Key render-target IDs exist | `home-stats/feature/timeline`, `search-input/results`, `greet-name`, `me-name` present |
| S7 | App script parses | No JS syntax error |

## Epic A — First run & navigation

| ID | Scenario | Expected |
|----|----------|----------|
| A1 | Fresh load, no batches | Dashboard shows empty state with "Start your first batch" CTA |
| A2 | Visit all 11 Library sections | Each renders substantive content (fruit-list → `#fruit-grid`) |
| A3 | Visit Batches, Lab Bench, Tasks, Inventory, Settings | Each renders content (regression for the missing-section bug) |

## Epic B — Create & manage a batch

| ID | Scenario | Expected |
|----|----------|----------|
| B1 | New Batch from a recipe | Batch created with correct `recipe_id`/`fruit_id` refids; appears in Batches |
| B2 | New Batch freeform from a fruit | `recipe_id` null; fruit/defaults applied |
| B3 | Inspect new record | Schema-conformant: `stage.planned`, `active`, readings/events/tasting_notes arrays, seeded `stage_history` |
| B4 | Return to dashboard | Featured card shows the most-recently-updated active batch |

## Epic C — Lifecycle & guardrails

| ID | Scenario | Expected |
|----|----------|----------|
| C1 | Advance through early stages | Reaches `bulk_aging` |
| C2 | Try to bottle before FG stable | **Blocked**; stage unchanged |
| C3 | Log two matching SG readings, then bottle | Allowed; advancing past bottling sets `bottled_at` + `outcome.bottle_count` |
| C4 | Back-sweeten without stabilizing | **Blocked**; allowed only after a stabilize event |
| C5 | Sparkling cider + sorbate → conditioning | **Blocked** (sorbate prevents carbonation) |
| C6 | Move back a stage | Stage order decrements |

## Epic D — Readings & computed fields

| ID | Scenario | Expected |
|----|----------|----------|
| D1 | Log OG and FG | ABV computes (≈ (OG−FG)×131.25) |
| D2 | Log out-of-range temperature | Attention flag raised |
| D3 | Log high pH with low free SO₂ | Attention flag raised |
| D4 | Time in stage/total | Both are numbers ≥ 0 |

## Epic E — Lab Bench

| ID | Scenario | Expected |
|----|----------|----------|
| E1 | Log with no batch selected | Guarded; nothing written |
| E2 | Log SG to selected batch | Reading appended (tagged "from Lab Bench") |
| E3 | Log a sugar addition | Event appended with `unit: lb` |
| E4 | Enter temperature in Celsius | Stored as canonical °F (20 °C → 68 °F) |

## Epic F — Tasks

| ID | Scenario | Expected |
|----|----------|----------|
| F1 | Add / complete / delete a task | List updates accordingly |
| F2 | Add a stage-based suggestion | Becomes a manual task |
| F3 | Dashboard "Tasks Today" | Shows the open-task count |

## Epic G — Inventory

| ID | Scenario | Expected |
|----|----------|----------|
| G1 | Add item + quick-add yeast/additive | Items appear in the cellar |
| G2 | Quantity stepper & delete | Qty changes; item removed |
| G3 | Recipe check | Shows in-stock ✓ vs missing with an Add action |

## Epic H — Settings

| ID | Scenario | Expected |
|----|----------|----------|
| H1 | Save name | Greeting + sidebar update |
| H2 | Toggle units to Celsius | Persists; `unitIsC()` reflects it |
| H3 | Set default batch size | New Batch wizard uses it |
| H4 | Reset all data | Batches/tasks/inventory cleared; settings retained |

## Epic I — Global search

| ID | Scenario | Expected |
|----|----------|----------|
| I1 | Query catalogues | Matches across fruit/yeast/additive/recipe/glossary/fault/section |
| I2 | Prefix vs substring | Prefix matches rank first |
| I3 | No match | Empty state shown |
| I4 | Select a result | Navigates without error |
| I5 | Search a batch name | User batches are searchable |

## Epic J — Persistence & integrity

| ID | Scenario | Expected |
|----|----------|----------|
| J1 | Create data, reload | State persists via localStorage |
| J2 | Storage availability | `storageOK()` returns a boolean (no crash if blocked) |

---

## Manual checks (not automated)

The harness cannot see layout/CSS. Do these by eye in a browser before release:

1. Responsive: sidebar collapses to a drawer < 880px; content reflows; the
   top search is hidden on narrow mobile (by design).
2. Visual polish: gradients, fruit motifs, tab switching, hover states.
3. Real persistence: create a batch, refresh the page, confirm it survives
   (only works when opened as a local file / served, not in a sandbox that
   blocks localStorage — Settings shows "Storage: Memory only" if blocked).
4. Keyboard: Enter selects the top search hit; Esc closes the dropdown.
5. The Troubleshooting page remains the static catalogue (the describe-your-
   issue assistant is intentionally deferred to the LLM-backed backend).

## Change log

- **2026-06-07** — Initial suite, 45 cases, 45/45 pass. Fixed two test-spec
  issues found during authoring (A2 must assert `#fruit-grid`; B4 must assert
  the most-recently-updated batch). Confirmed the earlier missing-section bug
  (Inventory/Lab Bench/Settings/Tasks) is fixed and now covered by S1 + A3.
