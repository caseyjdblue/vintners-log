#!/usr/bin/env node
/*
 * Fruited Plains Winery — UAT / End-to-End test harness
 * --------------------------------------------------------
 * Re-runnable acceptance + regression suite for the single-file app.
 * Usage:   node uat-harness.js [path-to-fruited-plains-winery.html]
 * Default: ./fruited-plains-winery.html (same directory)
 *
 * It runs two layers of checks:
 *   STRUCTURAL  — parses the HTML (router wiring, DOM sections, handlers, ids)
 *   BEHAVIORAL  — evaluates the app script against a DOM/localStorage stub and
 *                 drives realistic user journeys, asserting acceptance criteria.
 *
 * Exit code 0 = all pass, 1 = one or more failures.
 * See uat-test-plan.md for the human-readable test cases (IDs match).
 */
const fs = require('fs');
const path = process.argv[2] || (__dirname + '/fruited-plains-winery.html');
const html = fs.readFileSync(path, 'utf8');
const results = [];
function R(id, desc, ok, err) { results.push({ id, desc, ok: !!ok, err: err || null }); }

/* ----------------------------- STRUCTURAL ----------------------------- */
const script = html.match(/<script>([\s\S]*)<\/script>/)[1];
const staticHtml = html.slice(0, html.indexOf('<script>')) + html.slice(html.indexOf('</script>'));

const screens = (script.match(/const screens = \[([^\]]*)\]/)[1].match(/'[a-z-]+'/g) || []).map(s => s.replace(/'/g, ''));
const sections = new Set([...staticHtml.matchAll(/<section class="screen[^"]*" id="([a-z-]+)"/g)].map(m => m[1]));
const defined = new Set([...script.matchAll(/function\s+([A-Za-z_]\w*)\s*\(/g)].map(m => m[1]));

(() => { const miss = screens.filter(s => !sections.has(s)); R('S1', 'Every routed screen has a DOM section', miss.length === 0, miss.join(',')); })();
(() => {
  const handlers = [...html.matchAll(/on(?:click|change|input|keydown|mousedown|blur|focus)="([^"]*)"/g)].map(m => m[1]);
  const called = new Set(); handlers.forEach(h => [...h.matchAll(/([A-Za-z_]\w*)\s*\(/g)].forEach(m => called.add(m[1])));
  const builtins = new Set(['setTimeout', 'replace', 'select', 'blur', 'focus']);
  const undef = [...called].filter(n => !defined.has(n) && !builtins.has(n));
  R('S2', 'All event handlers reference defined functions', undef.length === 0, undef.join(','));
})();
(() => {
  const targets = new Set([...html.matchAll(/go\('([a-z-]+)'/g)].map(m => m[1]));
  const bad = [...targets].filter(t => !screens.includes(t)); R('S3', 'All go() targets are registered screens', bad.length === 0, bad.join(','));
})();
(() => {
  const ids = [...staticHtml.matchAll(/\sid="([a-zA-Z0-9_-]+)"/g)].map(m => m[1]);
  const seen = {}, dup = []; ids.forEach(i => { seen[i] = (seen[i] || 0) + 1; }); Object.keys(seen).forEach(k => { if (seen[k] > 1) dup.push(k); });
  R('S4', 'No duplicate element IDs in static DOM', dup.length === 0, dup.join(','));
})();
(() => {
  const soon = [...html.matchAll(/go\('soon','([^']+)'\)/g)].map(m => m[1]).filter(x => !x.includes('+'));
  R('S5', 'No "coming soon" dead-ends for built features', soon.length === 0, soon.join(','));
})();
(() => {
  const need = ['home-stats', 'home-feature', 'home-timeline', 'search-input', 'search-results', 'greet-name', 'me-name'];
  const ids = new Set([...staticHtml.matchAll(/\sid="([a-zA-Z0-9_-]+)"/g)].map(m => m[1]));
  const miss = need.filter(n => !ids.has(n)); R('S6', 'Key render-target IDs exist in static DOM', miss.length === 0, miss.join(','));
})();
(() => { let ok = true, err = null; try { require('vm').compileFunction(script); } catch (e) { ok = false; err = e.message; } R('S7', 'App script parses without syntax error', ok, err); })();

/* ----------------------------- BEHAVIORAL ----------------------------- */
const store = {};
global.localStorage = { getItem: k => (k in store ? store[k] : null), setItem: (k, v) => { store[k] = String(v); }, removeItem: k => { delete store[k]; } };
function fakeEl() { return { _html: '', set innerHTML(v) { this._html = v; }, get innerHTML() { return this._html; }, value: '', textContent: '', style: {}, classList: { add() {}, remove() {}, contains() { return false; }, toggle() {} }, focus() {}, blur() {}, select() {}, querySelectorAll() { return []; }, addEventListener() {}, appendChild() {}, remove() {} }; }
const els = {};
global.document = { getElementById: id => { if (!els[id]) els[id] = fakeEl(); return els[id]; }, querySelectorAll: () => [], querySelector: () => null, createElement: () => fakeEl(), addEventListener() {}, body: fakeEl() };
global.window = { scrollTo() {}, matchMedia: () => ({ matches: false, addEventListener() {} }), addEventListener() {} };
global.requestAnimationFrame = cb => cb(); global.confirm = () => true; global.alert = () => {};
global.__UAT = [];

const exercise = `
toast = function(){};
function T(id, desc, fn){ var ok=false, err=null; try{ ok=!!fn(); }catch(e){ err=e.message; } global.__UAT.push({id:id, desc:desc, ok:ok, err:err}); }
function setv(id,v){ document.getElementById(id).value = String(v); }
function reset(){ STORE.batches=[]; STORE.tasks=[]; STORE.inventory=[]; STORE.seq=1; saveStore(); }
function mkBatch(recId){ wizInit(); wizSource('recipe'); wizPickRecipe(recId); wizardState.step=2; wizNext(); wizNext(); createBatch(); return STORE.batches[STORE.batches.length-1]; }

/* Epic A — first run & navigation */
reset();
T('A1','Fresh dashboard shows empty state with CTA', function(){ renderHome(); return document.getElementById('home-feature').innerHTML.indexOf('first batch')>=0; });
T('A2','All 11 library sections render content', function(){ var r=['fruit-list','yeast-list','additives','recipes','sop','equipment','sanitation','calc','trouble','glossary','seasonal']; var tgt={'fruit-list':'fruit-grid'}; return r.every(function(s){ go(s); return document.getElementById(tgt[s]||s).innerHTML.length>80; }); });
T('A3','All app-feature screens render content', function(){ var r=['batches','labbench','tasks','inventory','settings']; return r.every(function(s){ go(s); return document.getElementById(s).innerHTML.length>60; }); });

/* Epic B — create & manage a batch */
reset();
T('B1','Create batch from recipe lands in Batches with refid', function(){ var b=mkBatch('1'); return STORE.batches.length===1 && b.recipe_id==='recipe.cherry_table' && b.fruit_id==='fruit.sweet_cherry'; });
T('B2','Create freeform batch from fruit (no recipe_id)', function(){ wizInit(); wizSource('fruit'); wizPickFruit('blackberry'); wizardState.step=2; wizNext(); wizNext(); createBatch(); var b=STORE.batches[STORE.batches.length-1]; return b.recipe_id===null && b.fruit_id==='fruit.blackberry'; });
T('B3','Batch record conforms to data-model schema', function(){ var b=STORE.batches[0]; return b.stage==='stage.planned' && b.status==='active' && Array.isArray(b.readings) && Array.isArray(b.events) && b.stage_history.length===1 && Array.isArray(b.tasting_notes); });
T('B4','Dashboard featured card shows the most-recently-updated batch', function(){ go('home'); var feat=STORE.batches.slice().sort(function(a,b){return new Date(b.updated_at)-new Date(a.updated_at);}).filter(function(x){return x.status==='active';})[0]; return document.getElementById('home-feature').innerHTML.indexOf(feat.name)>=0; });

/* Epic C — lifecycle & guardrails */
reset(); var cb=mkBatch('1'); openBatch(cb.id);
T('C1','Advance planned -> bulk_aging', function(){ advance('stage.fruit_prep'); advance('stage.must_prep'); advance('stage.primary'); advance('stage.secondary'); advance('stage.bulk_aging'); return cb.stage==='stage.bulk_aging'; });
T('C2','Bottling blocked until FG stable', function(){ advance('stage.bottling'); return cb.stage==='stage.bulk_aging'; });
T('C3','After 2 matching SG readings, bottling allowed + bottled_at/outcome set', function(){ setv('rd-type','sg'); setv('rd-val','0.995'); setv('rd-note',''); logReading(); setv('rd-val','0.995'); logReading(); advance('stage.bottling'); var okB=cb.stage==='stage.bottling'; advance('stage.cellaring'); return okB && !!cb.bottled_at && cb.outcome && cb.outcome.bottle_count>0; });
reset(); var ob=mkBatch('6'); openBatch(ob.id);
T('C4','Back-sweeten blocked without stabilize, allowed after', function(){ setv('ev-type','back_sweeten'); setv('ev-amt',''); setv('ev-note',''); logEvent(); var blocked=ob.events.length===0; setv('ev-type','stabilize'); logEvent(); setv('ev-type','back_sweeten'); logEvent(); return blocked && ob.events.filter(function(e){return e.type==='back_sweeten';}).length===1; });
reset(); var sp=mkBatch('8'); openBatch(sp.id);
T('C5','Sparkling: conditioning blocked when sorbate used', function(){ ['stage.fruit_prep','stage.must_prep','stage.primary','stage.secondary'].forEach(advance); setv('rd-type','sg'); setv('rd-val','0.999'); setv('rd-note',''); logReading(); setv('rd-val','0.999'); logReading(); advance('stage.bulk_aging'); setv('ev-type','stabilize'); setv('ev-amt',''); setv('ev-note',''); logEvent(); advance('stage.bottling'); advance('stage.conditioning'); return sp.stage==='stage.bottling'; });
reset(); var mb=mkBatch('1'); openBatch(mb.id);
T('C6','Move back a stage decrements stage order', function(){ advance('stage.fruit_prep'); advance('stage.must_prep'); var before=stageIdx(mb.stage); moveBack(); return stageIdx(mb.stage)===before-1; });

/* Epic D — readings & computed fields */
reset(); var db=mkBatch('5'); openBatch(db.id);
T('D1','ABV computes from OG and FG readings', function(){ setv('rd-type','og'); setv('rd-val','1.090'); setv('rd-note',''); logReading(); setv('rd-type','fg'); setv('rd-val','0.995'); logReading(); var a=abvNow(db); return a>12 && a<13; });
T('D2','Out-of-range temperature raises a flag', function(){ setv('rd-type','temperature'); setv('rd-val','95'); setv('rd-note',''); logReading(); return computeFlags(db).some(function(f){return f.sev==='warn' && f.msg.indexOf('temp')>=0;}); });
T('D3','High pH + low SO2 raises a flag', function(){ setv('rd-type','ph'); setv('rd-val','3.8'); setv('rd-note',''); logReading(); setv('rd-type','free_so2'); setv('rd-val','10'); logReading(); return computeFlags(db).some(function(f){return f.msg.indexOf('SO')>=0;}); });
T('D4','Days-in-stage and total are numbers >= 0', function(){ return daysInStage(db)>=0 && daysTotal(db)>=0; });

/* Epic E — Lab Bench */
reset(); var eb=mkBatch('5');
T('E1','Lab logging is guarded with no batch selected', function(){ labState.batchId=''; renderLabBench(); setv('lb-gval','1.040'); labLogReading('sg','lb-gval'); return eb.readings.length===0; });
T('E2','Lab logs SG reading to the selected batch', function(){ labState.batchId=eb.id; renderLabBench(); setv('lb-gval','1.030'); labLogReading('sg','lb-gval'); var r=eb.readings[eb.readings.length-1]; return r && r.type==='sg' && r.value===1.03 && r.note==='from Lab Bench'; });
T('E3','Lab logs sugar addition as an event', function(){ setv('lb-scur','1.040'); setv('lb-stgt','1.090'); setv('lb-sgal','5'); labLogSugar(); return eb.events.some(function(e){return e.type==='sugar_addition' && e.unit==='lb';}); });
T('E4','Celsius input is stored as canonical Fahrenheit', function(){ STORE.settings.units='C'; renderLabBench(); setv('lb-temp','20'); labLogReading('temperature','lb-temp'); var t=eb.readings.filter(function(r){return r.type==='temperature';}).pop(); STORE.settings.units='F'; return Math.abs(t.value-68)<0.6; });

/* Epic F — Tasks */
reset(); var fb=mkBatch('5');
T('F1','Add, complete, and delete a manual task', function(){ setv('tk-title','Rack off lees'); setv('tk-batch',fb.id); addTask(); setv('tk-title','Buy Campden'); setv('tk-batch',''); addTask(); var added=STORE.tasks.length===2; var id0=STORE.tasks[0].id; toggleTask(id0); var toggled=STORE.tasks[0].done===true; deleteTask(STORE.tasks[1].id); return added && toggled && STORE.tasks.length===1; });
T('F2','Suggested task from batch stage can be added', function(){ openBatch(fb.id); advance('stage.fruit_prep'); advance('stage.must_prep'); advance('stage.primary'); var n=STORE.tasks.length; addSuggested(fb.id, STAGE_REMINDERS['stage.primary'][0]); return STORE.tasks.length===n+1; });
T('F3','Dashboard Tasks Today reflects open count', function(){ renderHome(); var open=STORE.tasks.filter(function(t){return !t.done;}).length; return document.getElementById('home-stats').innerHTML.indexOf('Tasks Today')>=0 && document.getElementById('home-stats').innerHTML.indexOf('>'+open+'<')>=0; });

/* Epic G — Inventory */
reset();
T('G1','Add item and quick-add yeast/additive', function(){ renderInventory(); setv('inv-name','Frozen blueberries'); setv('inv-cat','fruit'); setv('inv-qty','6'); setv('inv-unit','lb'); invAdd(); setv('qa-yeast','rc212'); invQuickAddYeast(); setv('qa-add','sulfite'); invQuickAddAdditive(); return STORE.inventory.length===3; });
T('G2','Quantity stepper and delete work', function(){ var blue=STORE.inventory.find(function(i){return i.name==='Frozen blueberries';}); invStep(blue.id,2); var stepped=STORE.inventory.find(function(i){return i.id===blue.id;}).qty===8; invDelete(blue.id); return stepped && STORE.inventory.length===2; });
T('G3','Recipe check detects in-stock vs missing', function(){ recipeCheck('5'); var out=document.getElementById('rc-out').innerHTML; return out.indexOf('In stock')>=0 && out.indexOf('>Add<')>=0; });

/* Epic H — Settings */
reset();
T('H1','Saving name updates greeting and sidebar', function(){ renderSettings(); setv('set-name','Casey W'); setv('set-units','F'); setv('set-gal','5'); settingsSave(); return document.getElementById('greet-name').textContent==='Casey W' && document.getElementById('me-name').textContent==='Casey W'; });
T('H2','Temperature unit persists', function(){ renderSettings(); setv('set-name','Casey W'); setv('set-units','C'); setv('set-gal','5'); settingsSave(); var persisted=JSON.parse(localStorage.getItem('fpw_store')).settings.units==='C'; STORE.settings.units='F'; saveStore(); return persisted && unitIsC()===false; });
T('H3','Default batch size flows into the wizard', function(){ STORE.settings.defaultBatchGal=3; saveStore(); wizInit(); return wizardState.sizeGal===3; });
T('H4','Reset clears data but keeps settings', function(){ mkBatch('1'); var name=STORE.settings.name; settingsReset(); return STORE.batches.length===0 && STORE.tasks.length===0 && STORE.inventory.length===0 && STORE.settings.name===name; });

/* Epic I — Global search */
reset(); mkBatch('5');
T('I1','Search matches across catalogues', function(){ searchInput('blue'); var hasFruit=SEARCH_HITS.some(function(e){return e.sub==='Fruit';}); searchInput('campden'); var hasAdd=SEARCH_HITS.length>0; searchInput('rc212'); var hasYeast=SEARCH_HITS.some(function(e){return e.sub==='Yeast';}); return hasFruit && hasAdd && hasYeast; });
T('I2','Prefix matches rank first', function(){ searchInput('blue'); return SEARCH_HITS[0] && SEARCH_HITS[0].title.toLowerCase().indexOf('blue')===0; });
T('I3','No-match shows empty state', function(){ searchInput('zzzznope'); return document.getElementById('search-results').innerHTML.indexOf('No matches')>=0; });
T('I4','Selecting a result navigates without error', function(){ searchInput('recipes'); var before=SEARCH_HITS.length; searchGo(0); return before>0; });
T('I5','User batches are searchable', function(){ var b=STORE.batches[0]; searchInput(b.name.slice(0,5).toLowerCase()); return SEARCH_HITS.some(function(e){return e.title===b.name;}); });

/* Epic J — persistence & integrity */
T('J1','State persists to localStorage and reloads', function(){ reset(); mkBatch('1'); var parsed=JSON.parse(localStorage.getItem('fpw_store')); return parsed.batches.length===1; });
T('J2','storageOK() reports a boolean without throwing', function(){ return typeof storageOK()==='boolean'; });
`;

try { eval(script + '\n' + exercise); }
catch (e) { R('FATAL', 'Behavioral suite threw before completing', false, e.message); }
(global.__UAT || []).forEach(t => R(t.id, t.desc, t.ok, t.err));

/* ----------------------------- REPORT ----------------------------- */
const pass = results.filter(r => r.ok).length, fail = results.length - pass;
console.log('\nFruited Plains Winery — UAT results  (' + new Date().toISOString().slice(0, 10) + ')');
console.log('source: ' + path);
console.log('='.repeat(64));
results.forEach(r => console.log((r.ok ? ' PASS ' : ' FAIL ') + r.id.padEnd(6) + ' ' + r.desc + (r.ok ? '' : '  <<< ' + (r.err || 'assertion false'))));
console.log('='.repeat(64));
console.log('TOTAL ' + results.length + '   PASS ' + pass + '   FAIL ' + fail + '\n');
process.exit(fail ? 1 : 0);
